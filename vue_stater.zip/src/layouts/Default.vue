<template>
  <div class="defaut-layout">
      <slot />
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.defaut-layout {
    background: rgb(172, 171, 171);
}
</style>