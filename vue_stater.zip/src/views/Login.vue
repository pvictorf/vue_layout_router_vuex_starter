<template>
  <div class="login">
    <h1>This is an login page</h1>
  </div>
</template>

<script>
export default {

}
</script>