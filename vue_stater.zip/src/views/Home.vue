<template>
  <div class="home-page">
      <h1>Home!</h1>
      <router-link to="/login">Login</router-link>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>